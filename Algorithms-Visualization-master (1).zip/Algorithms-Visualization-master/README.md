# Algorithm-Visualization

### <a href = "https://elysian01.github.io/Algorithms-Visualization/"> Click here </a> to view website

## Pathfinding Algorithms

* Breadth First Search
* Depth First Search
* Best First Search
* Dijkstra Algorithm
* Astar Algorithm

## Searching Algorithms

* Linear Search
* Jump Search
* Binary Search
* Exponential Search
